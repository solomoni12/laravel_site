<footer id="footer">
    <div class="container">
       <h4>Follow us</h4>
      <div class="social-links">
        <!-- <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a> -->
        <a href="https://www.facebook.com/solomon.mwalupani?mibextid=LQQJ4d" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://wa.me/message/7PEPIIJ2JBYSI1" class="whatsapp"><i class="bx bxl-whatsapp"></i></a>
        <a href="https://www.instagram.com/mwalupanisolomon/" class="instagram"><i class="bx bxl-instagram"></i></a>
        <a href="https://www.linkedin.com/in/solomon-mwalupani-08225b25b/" class="linkedin"><i class="bx bxl-linkedin"></i></a>
      </div>
      <div class="copyright">
        &copy; Copyright <strong><span>Sologroup</span></strong>. All Rights Reserved
      </div>
      <div class="credits">

        Designed by <a href="https://solo.com/">Solomon Developer</a>
      </div>
    </div>
  </footer>