<script src="frontend/assets/vendor/aos/aos.js"></script>
<script src="frontend/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="frontend/assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="frontend/assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="frontend/assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="frontend/assets/vendor/php-email-form/validate.js"></script>

<!-- Template Main JS File -->
<script src="frontend/assets/js/main.js"></script>
<?php /**PATH M:\Sologroup\sologroupapp\resources\views/home/js.blade.php ENDPATH**/ ?>